# AI-based-hourly-attendance-presence-calculation-using-AWS
